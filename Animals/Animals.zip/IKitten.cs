﻿namespace Animals
{
    public interface IKitten
    {
        string ProduceSound();
    }
}